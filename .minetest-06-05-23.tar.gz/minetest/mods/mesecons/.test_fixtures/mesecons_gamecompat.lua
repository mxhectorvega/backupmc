fixture("mesecons")

mineunit:set_current_modname("mesecons_gamecompat")
mineunit:set_modpath("mesecons_gamecompat", "../mesecons_gamecompat")
sourcefile("../mesecons_gamecompat/init")
