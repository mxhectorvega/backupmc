Credits of sound files:

Note: Most sounds have not been used verbatim, but tweaked a little to be more suitable for the noteblock mod.

* mesecons_noteblock_litecrash.ogg
	* License: CC BY 3.0
	* by freesound.org user ani_music
	* Source: https://freesound.org/people/ani_music/sounds/219612/

Everything else:
Created by Mesecons authors, licensed CC BY 3.0.

--------------------
License links:
* CC BY 3.0: http://creativecommons.org/licenses/by/3.0/
