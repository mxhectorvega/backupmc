-- mineunit doesn't yet implement minetest.get_objects_inside_radius
pending("object movement", function()
end)
